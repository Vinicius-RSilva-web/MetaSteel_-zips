/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author QI
 */
public class Clientes extends Cliente {
    private int id;
    private String nome;
    private String cpf;
    private String senhaCliente;

    

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String getCpf() {
        return cpf;
    }

    @Override
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSenha() {
        return senhaCliente;
    }

    public void setSenha(String senha) {
        this.senhaCliente = senha;
    }

    public Clientes(int id, String string, String string1, String string2) {
        super(id);
    }
    @Override
    public String toString() {
        return "Nome: " + nome + " CPF: "+ cpf + "ID: "+ id + "Senha: " +senhaCliente;
        
    }
    
    
}
