<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        .logins{
            display: flex;
            flex-wrap: wrap;
            width: 625px;
            align-items: center;
            gap: 25px;
            margin-top: 30px;
            margin-left: 350px;
        }
        .login{
            background: #fff;
            border-radius: 5px;
            overflow: hidden;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,.2);
            width: 425px;
            align-self: center;
        }
        *{
            margin:0;
            padding:0;
            box-sizing: border-box;
            font-family: Segoe UI, sans-serif;
        }

        body{
            background: #706969;
            display: flex;
        }
        .main{
            margin-left: 250px;
            width: calc(100% - 250px);
            padding: 25px;
        }
        .h2{
            padding: 25px;
            align-content: center;
        }
        .form{
            padding: 45px;
        }
        @media(max-width:768px) {
                .sidebar{
                    width: 100%;
                    height: auto;
                    position: relative;
                }
                .main{
                    margin-left: 0;
                    width: 100%;
                }
                body{
                    flex-direction: column;
                }
            }
    </style>
</head>
<body>
    <div class="logins">    
<div class="login">
<h2>Login</h2>

<form action="login.jsp" method="post">

    <label>Usuário</label><br>
    <input type="text" name="usuario"><br><br>
    
    <label>Contato</label><br>
    <input type="number" name="contato"><br></br>

    <label>Senha</label><br>
    <input type="password" name="senha"><br><br>

    <a href="index.html">Entrar</a>

</form>
</div>
</div>
<%
    String usuario = request.getParameter("usuario");
    String senha = request.getParameter("senha");
    String contato = request.getParameter("contato");

    if (usuario != null && senha != null) {

        if (usuario.equals("admin") && senha.equals("1234") && contato.equals("551001452")) {
%>

    <h3 style="color:green;">Login realizado com sucesso!</h3>

<%
        } else {
%>

    <h3 style="color:red;">Usuário ou senha incorretos!</h3>

<%
        }

    }
%>

</body>
</html>