package model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author QI
 */
public class Empresa {
    private String razaoSocial;
    private String cnpj;
    private String endereco;
    private String telefone;
    private String email;
    
    public Empresa(String razaoSocial, String cnpj, String endereco, String telefone, String email){
        this.razaoSocial= razaoSocial;
        this.cnpj= cnpj;
        this.endereco= endereco;
        this.telefone= telefone;
        this.email= email;
        
    }
    public Empresa(){}
    
    public String getRazaoSocial(){
        return razaoSocial;
}
    public void setRazaoSocial(String razaoSocial){
        this.razaoSocial= razaoSocial;
}
    public String getCnpj(){
        return cnpj;
}
    public void setCnpj(String cnpj){
        this.cnpj= cnpj;
}
    public String getEndereco(){
        return endereco;
}
    public void setEndereço(String endereco){
      this.endereco= endereco;
}
    public String getTelefone(){
        return telefone;
}
    public void setTelefone(String telefone){
        this.telefone= telefone;
}
    public String getEmail(){
        return email;
}
    public void setEmail(String email){
        this.email= email;
}
@Override
public String toString(){
    return "Empresa: "+razaoSocial + 
            "|CNPJ: "+ cnpj +
            "|Enderço: "+ endereco +
            "|Telefone: "+telefone +
            "|Email: "+email;
}



}