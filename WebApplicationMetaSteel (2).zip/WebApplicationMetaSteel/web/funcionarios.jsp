<%-- 
    Document   : funcionarios
    Created on : 14 de jul. de 2026, 19:08:08
    Author     : QI
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%
            String usuario = request.getParameter("usuario");
            String senha = request.getParameter("senha");

            if(usuario != null && senha != null){

                if(usuario.equals("admin") && senha.equals("1234")){
                    response.sendRedirect("index.html");
                }else{
        %>

        <script>
        alert("Usuário ou senha inválidos!");
        window.location="index.jsp";
        </script>

        <%
                }
            }
        %>
    </body>
</html>
