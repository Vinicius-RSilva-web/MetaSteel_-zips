<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.Empresa"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <style>
           *{
                margin:0;
                padding:0;
                box-sizing: border-box;
                font-family: Segoe UI, sans-serif;
            }

            body{
                background: #706969;
                display: flex;
            }

            .sidebar{
                width: 250px;
                height: 100vh;
                background: #F7D4C9;
                background: linear-gradient(0deg,rgba(247, 212, 201, 1) 0%, rgba(252, 105, 0, 1) 76%);
                color: gray;
                position: fixed;
                left: 0;
                top: 0;
            }

            .logo{
                padding: 20px;
                font-size: 24px;
                font-weight: bold;
                border-bottom: 1px solid rgba(255,255,255,.1);
            }

            .menu{
                list-style: none;
            }

            .menu li{
                padding: 15px 20px;
                cursor: pointer;
                transition: 0.3s;
            }

            .menu li:hover{
                background: #374151;
            }

            .menu li.active{
                background: #d4d4d4;
            }

            .main{
                margin-left: 250px;
                width: calc(100% - 250px);
                padding: 25px;
            }

            .header{
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 25px;
            }

            .user{
                background: white;
                padding: 10px 15px;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,.08);
            } 
            .logo img{
                width: 100%;
                height: 145px;
                object-fit: cover;
            }
            .cards{
                display: flex;
                flex-direction: column;
                gap: 25px;
                margin-top: 30px;
                margin-left: 235px;
                
            }
            
            .contato{
                background: #fff;
                border-radius: 5px;
                overflow: hidden;
                padding: 25px;
                width: 925px;
                height: 565px;
                box-shadow: 0 2px 5px rgba(0,0,0,.2);
                font-size: 18px;
                margin-left: 275px;
                margin-top: 30px;
            }
            @media(max-width:768px) {
                .sidebar{
                    width: 100%;
                    height: auto;
                    position: relative;
                }
                .main{
                    margin-left: 0;
                    width: 100%;
                }
                body{
                    flex-direction: column;
                }
                .cards{
                    flex-direction: column;
                }
            }
            
        </style>
    </head>
    <body>
        <div class="sidebar">
            <div class="logo">
                <img src="img/logo.png" alt="Logo">
            </div>
            <ul class="menu">
                <li><a href="login.jsp">Login</a></li>
                <li><a href="index.html">Início</a></li>
                <li><a href="tela2.html">Produtos</a></li>
                <li>Compras</li>
                <li>Carrinho</li>
                <li><a class="active">Contato</a></li>
                <li><a href="funcionarios.html">Funcionarios</a></li>
                
            </ul>
            
        </div>
        <div class="cads">
        <div class="contato">
        <%
            Empresa e1 = new Empresa(
            "MetaSteel",
            "45.678822/1256-70",
            "Rua Pinheiro Machado, 7852",
            "(54)2342-4483",
            "contato@MetaSteel.com"
            );
            
            Empresa e2 = new Empresa();
            e2.setRazaoSocial("IronByte");
            e2.setCnpj("47.738.834/1256-12");
            e2.setEndereço("Av. Julio de Castilho, 472");
            e2.setTelefone("(54)99923-3367");
            e2.setEmail("vendas@IronByte.com");
            
            %>
            <h2>MetaSteel:</h2>
            <br>
            <p><%= e1.toString()%></p>
            <br>
            
            <h2>MetaSteel:</h2>
            <br>
            <p>Razão Social <%= e2.getRazaoSocial()%></p>
            <p>CNPJ: <%= e2.getCnpj()%></p>
            <p>Endereço: <%= e2.getEndereco() %></p>
            <p>Telefone: <%= e2.getTelefone() %></p>
            <p>Email: <%= e2.getEmail() %></p>
            <br>
            
            <h2>IronByte:</h2>
            <br>
            <p><%= e2.toString() %></p>
            <br>
        </div>
        </div>
    </body>
</html>
