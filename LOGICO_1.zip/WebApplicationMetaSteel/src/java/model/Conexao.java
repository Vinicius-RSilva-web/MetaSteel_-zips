package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Conexao {

    private final String driver = "com.mysql.cj.jdbc.Driver";
    private final String servidor ="jdbc:mysql://localhost/phpmyadmin/index.php?route=/database/structure&db=metasteel";
    private final String usuario = "root";
    private final String senha = "";
    

    private Connection conectar() {
        try {
            Class.forName(driver);
            return DriverManager.getConnection(servidor, usuario, senha);
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println(ex);
            return null;
        }
    }
    public ArrayList<Usuario> usuariotb() {

        ArrayList<Usuario> arrayUsuario = new ArrayList<>();

        try {

            ResultSet listaUsuarios = conectar()
                    .createStatement()
                    .executeQuery("select * from usuario");

            while (listaUsuarios.next()) {

                arrayUsuario.add(new Usuarios(
                        listaUsuarios.getInt("id"),
                        listaUsuarios.getString("nome"),
                        listaUsuarios.getString("cpf"),
                        listaUsuarios.getString("senha")
                ));
            }

        } catch (Exception ex) {
            System.out.println(ex);
        }

        return arrayUsuario;
    }
}